package deloite;

import java.util.LinkedHashMap;
import java.util.LinkedList;

public class frequencyOfeachchar {

    public static void main(String[] args) {
        String s="MaNjunath".toLowerCase();
        LinkedHashMap<Character, Integer> map=new LinkedHashMap<>();
        int count=0;
        for(int i=0; i<s.length();i++){
            char c=s.charAt(i);

            if (map.containsKey(c)){
                map.put(c,map.get(c)+1)  ;
            }else{
              map.put(c,1) ;
            }

        }
        System.out.println(map);
    }
}
