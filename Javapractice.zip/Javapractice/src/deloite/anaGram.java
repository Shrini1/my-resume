package deloite;

import java.lang.reflect.Array;
import java.util.Arrays;

public class anaGram {

    public static void main(String[] args) {
        String s="silent";
        String s2= "lisent";
        char [] a1=s.toCharArray();
        char [] a2=s2.toCharArray();

        Arrays.sort(a1);
        Arrays.sort(a2);
        if(Arrays.toString(a1).equals(Arrays.toString(a2))){
            System.out.println("anagram");
        }
    }
}
