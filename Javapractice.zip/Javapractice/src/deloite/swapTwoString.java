package deloite;

public class swapTwoString {
    public static void main(String[] args) {
        String word="first";
        String word2="second";
        String temp=word;
        word=word2;
        word2=temp;
        System.out.println(word+" "+word2 );
        String word3="third";
        String word4="fourth";

        word3=word3+word4;
        word4=word3.substring(0,word3.length()-word4.length());
        word3=word3.substring(word4.length());
        System.out.println(word3+" "+word4 );





    }
}
