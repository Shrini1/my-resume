package deloite;

public class palindromenumbber {
    public static void main(String[] args) {
        int num=121;
        int rev=0;
        int temp=num;

        while(num!=0){
            int lasdigit=num%10;
            rev=rev*10+lasdigit;
            num=num/10;
        }
        if(temp==rev){
            System.out.println("its a palindroe");
        }

    }
}
