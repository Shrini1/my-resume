package deloite;

public class vowelsAndConsonants {
    public static void main(String[] args) {
        String S="Shrinivas".toLowerCase();
        int vowels=0;
        int Consontants=0;


        for (int i=0; i<S.length();i++){
            char c=S.charAt(i);
            if(c=='a'|| c=='e' || c=='i'||c=='o'||c=='u'){
                vowels++;
            }else {
                Consontants++;
            }
        }
        System.out.println("In the given string the vowels and consonant counts are "+vowels+" & "+Consontants);

    }
}
