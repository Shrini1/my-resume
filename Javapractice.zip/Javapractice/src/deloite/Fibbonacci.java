package deloite;

import java.util.Arrays;

public class Fibbonacci {

    public static void main(String[] args) {
        int a=1;
        int b=3;
        int n=5;
        int third;
int [] input={1,3,4,7,11,18,29,47};
       System.out.print(a+","+b);
        for(int i=0; i<=n; i++){
            third=a+b;
            a=b;    //3
            b=third; //4
            System.out.print(","+third);
        }





    }
}
