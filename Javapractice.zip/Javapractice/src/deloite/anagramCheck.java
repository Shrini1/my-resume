package deloite;

import java.util.Arrays;
import java.util.TreeSet;

public class anagramCheck {
    public static void main(String[] args) {
        String s1="silent";
        String s2="lisent";

        char[] c1=s1.toCharArray();
        char[] c2=s2.toCharArray();
        Arrays.sort(c1);
        Arrays.sort(c2);
        System.out.println(Arrays.toString(c1) +" "+ Arrays.toString(c2));
       if(Arrays.toString(c1).equals(Arrays.toString(c2))){
           System.out.println("its a anagram");
       }else{
           System.out.println("its not anagram");
       }


    }
}
