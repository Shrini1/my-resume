package deloite;

public class longestWordInSentence {
    public static void main(String[] args) {
        String Sentence="Hi Manjunath loves Aishhwaryaaaaa";
        String [] words=Sentence.split(" ");  //4
        String longestword=words[0];  //

        for(int i=1; i<words.length; i++ ){
            if(longestword.length()< words[i].length()){
                longestword=words[i];
            }

        }
        System.out.println(longestword);
    }
}
