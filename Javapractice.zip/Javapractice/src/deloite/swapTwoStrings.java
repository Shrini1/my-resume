package deloite;

public class swapTwoStrings {

    public static void main(String[] args) {
        String s1="Shri";
        String s2="Shri2";
        String Temp=s1;  //shri1
        s1=s2;  //shri1
        s2=Temp;
        System.out.println(s1+" "+s2);

        //.............witouthird variable..............//
        String word1="words";
        String word2="Numbers";

        word2=word2+word1; //numberswords
        word1=word2.substring(0,word2.length()-word1.length());
        word2=word2.substring(word1.length());

        System.out.println(word1+" "+word2);


    }
}
