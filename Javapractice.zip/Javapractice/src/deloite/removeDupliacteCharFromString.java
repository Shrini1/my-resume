package deloite;

import java.util.LinkedHashSet;
import java.util.TreeSet;

public class removeDupliacteCharFromString {
    public static void main(String[] args) {
        String word="Shrinivas".toLowerCase();
        LinkedHashSet<String> T=new LinkedHashSet<>();
        for(int i=0; i<word.length(); i++){
         T.add(String.valueOf(word.charAt(i)));
        }
        System.out.println(T);
    }
}
