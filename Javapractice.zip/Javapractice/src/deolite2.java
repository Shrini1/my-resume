public class deolite2 {
}
