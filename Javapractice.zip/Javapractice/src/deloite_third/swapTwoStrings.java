package deloite_third;

public class swapTwoStrings {

    public static void main(String[] args){
        String word="First";
        String word2="second";
        String temp=word;
        word=word2;
        word2=temp;
        //System.out.print(word+" "+word2);

        String word3="First";
        String word4="second";

        word3=word4+word3; //secondfirst
        word4=word3.substring(word4.length());
        word3=word3.substring(0,word4.length()+1);  //second
       // word4=word3.substring(word4.length());
        System.out.print(word3+" "+word4);

    }
}
