package deloite_third;

import java.util.LinkedHashSet;
import java.util.TreeSet;

public class duplicateCharFromString {

    public static void main(String[] args) {
        String S = "Shrinivas".toLowerCase();
      LinkedHashSet<Character> set = new LinkedHashSet<> ();
        for (int i = 0; i < S.length(); i++) {
            set.add(S.charAt(i));
        }
        System.out.print(set);
    }
}

