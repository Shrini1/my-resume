package deloite_third;

import java.util.Arrays;

public class anaGram {

    public static void main(String[] args){

        char[] word="Manjunath".toLowerCase().toCharArray();
        char[] word2="athmanju".toLowerCase().toCharArray();

        Arrays.sort(word);
        Arrays.sort(word2);

        if(Arrays.equals(word, word2))
        {
            System.out.println("its anagram");
        }else{
            System.out.println("its not anagram");
        }
    }
}
