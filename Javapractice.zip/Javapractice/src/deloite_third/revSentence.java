package deloite_third;

public class revSentence {
    public static void main(String[] args) {
        String sentence="today is sunday";

        String rev="";
        for (int i=sentence.length()-1;i>=0;i--){
            rev+=sentence.charAt(i);
        }
      //  System.out.println(rev);
        for(int i=rev.length()-1;i>=0;i--){
             rev+=rev.charAt(i);
            }
        System.out.println(rev);
    }
}
