package deloite_third;

public class VowelsCons {
    public static void main(String[] args){
        String s="shrinivas".toLowerCase();
        int vowels=0;
        int consonants=0;
        for(int i=0; i<s.length();i++){
            char c=s.charAt(i);
            if(c=='a'| c=='e'|c=='i'| c=='o'| c=='u'){
                vowels++;
            } else{
                consonants++;
            }
        }
        System.out.print(vowels+" "+consonants);
    }
}
