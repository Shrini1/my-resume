package deloite_third;

import java.util.LinkedHashMap;
import java.util.Set;

public class frequencyOfEachCharInString {

    public static void main(String[] args) {
        String word = "ManjMunath";
        LinkedHashMap<Character, Integer> map = new LinkedHashMap<>();
                Set<Character> s=map.keySet();
        for (int i = 0; i < word.length(); i++) {
            char c = word.charAt(i);
            if (map.containsKey(c)) {
                map.put(c, map.get(c) + 1);

            } else {
                map.put(c, 1);
            }

        }
        for(Character characters: map.keySet()){
            if(map.get(characters)==1){
                System.out.println(characters+" "+ map.get(characters));
                break;
            }
        }
    }
}
