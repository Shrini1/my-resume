package deloite_third;

public class revWordInsentence {

    public static void main(String [] args){

        String  sentence="Hi i am SHRINIVAS devihosur";
        String[] Words=sentence.split(" ");

        for(String word: Words){
            for (int i=word.length()-1; i>=0; i--){
                System.out.print(word.charAt(i));
            }
            System.out.print(" ");
        }

    }
}

