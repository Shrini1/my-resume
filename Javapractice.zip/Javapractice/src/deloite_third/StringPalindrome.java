package deloite_third;

public class StringPalindrome {
    public static void main(String[] args) {
        String s="GADAG";
        int n= s.length();
        boolean isPalindrome=true;
        for(int i=0; i<=n/2; i++){
            if (s.charAt(i)!=s.charAt(n-i-1)){
              isPalindrome=false;
                break;
            }
        }
        System.out.println(isPalindrome);
    }
}
