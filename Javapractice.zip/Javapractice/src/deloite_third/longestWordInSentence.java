package deloite_third;

public class longestWordInSentence {

    public static void main(String[] args){
        String sentence="small LOngest did word";
        String[] words=sentence.split(" ");
        String LongestWord=words[0];
        for(int i=0; i<words.length; i++){
            if(LongestWord.length()<words[i].length()){
                LongestWord=words[i];
            }
        }
        System.out.print(LongestWord);
    }
}
