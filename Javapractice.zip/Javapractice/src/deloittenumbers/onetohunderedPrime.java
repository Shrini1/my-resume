package deloittenumbers;

public class onetohunderedPrime {

    public static void main(String[] args) {

        for(int num=0; num<=100; num++){
            boolean isPrime=true;
            if(num<=1){
                isPrime=false;
            }
            for (int div=2; div<=num/2;div++){
                if(num%div==0){
                    isPrime=false;
                    break;
                }
            }
            if(isPrime) {
                System.out.print(num+", ");
            }
        }
    }
}
