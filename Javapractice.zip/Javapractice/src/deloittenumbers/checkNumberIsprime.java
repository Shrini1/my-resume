package deloittenumbers;

public class checkNumberIsprime {
    public static void main(String[] args) {
        int num=1;
        boolean isPrime=true;
        if(num<=1){
            isPrime=false;
        }
        for (int i=2; i<num/2; i++){
          if(num%i==0){
              isPrime=false;
          }
          if(isPrime) {
              System.out.println("its a prime");
          }


    }
}}
