package deloittenumbers;

public class armStrongNumber {

    public static void main(String[] args) {

        int num=153;
        int original=num;
        int sum=0;
        while(num>0){
            int lastdigit=num%10;
            sum+=lastdigit*lastdigit*lastdigit;
            num=num/10;
        }
        System.out.println(sum);
        if(sum==original){
            System.out.println(sum +" & "+num+" is matching so its a armstrong");
        }else {
            System.out.println("its not a armstrong");
        }
    }
}
