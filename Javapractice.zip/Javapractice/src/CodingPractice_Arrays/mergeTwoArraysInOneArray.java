package CodingPractice_Arrays;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.stream.IntStream;

public class mergeTwoArraysInOneArray {
    public static void main(String[] args) {
        LinkedHashMap<String, Integer> map2 = new LinkedHashMap<>();
        String[] array1 = {"Shrinivas", "Manju", "m", "Suraj", "Kirat", "Kirathana", "Kirathana", "Shrinivas", "Manju", "US", "Manju"};
        String[] array2 = {"Shrinivas", "Manju", "x", "m", "d", "k", "l", "mn", "opq", "rs", "m", "Shrinivas"};

        String[] result = new String[array1.length + array2.length]; //
        System.arraycopy(array1, 0, result, 0, array1.length); //Array 1
        System.arraycopy(array2, 0, result, array1.length, array2.length); //array 2
        System.out.println(Arrays.toString(result));

        //java 8 logic
        int [] array3 = {1,2,3,4};
        int [] array4 = {5,6,7,8};

        int[] result2= IntStream.concat(Arrays.stream(array3),Arrays.stream(array4)).toArray();
        System.out.println(Arrays.toString(result2));
    }
}
