package CodingPractice_Arrays;

import java.util.LinkedHashMap;
import java.util.Scanner;

public class findPairInAnArray {
    public static void main(String[] args) {
       // int [] a={1,'2','3','4','5','6','7','8'};
        int [] a={1,2,3,4,5,6};  //1+2 1+3 1+4
        Scanner SC=new Scanner(System.in);
        int input=SC.nextInt();
        int sum=0;
        boolean found=false;
        LinkedHashMap<Integer, Integer> map=new LinkedHashMap<>();
        for(int i=0; i<a.length;i++){ //2
            for(int j=i+1; j<a.length;j++){ //2 3
            sum =a[i]+a[j];
                if(sum==input){
                    System.out.println(a[i]+" , "+ a[j]);
                    found=true;
                }

            }//    System.out.println(map);

        }
        if(!found){
            System.out.println("NOt found");
        }

    }
}
