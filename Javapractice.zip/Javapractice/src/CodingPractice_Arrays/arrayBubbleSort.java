package CodingPractice_Arrays;

import java.util.Arrays;
import java.util.TreeSet;

public class arrayBubbleSort {
    public static void main(String[] args) {
//        TreeSet<Integer> T=new TreeSet<>();
//        int [] a= {5,1,2,7,6,9,2};
//        for (int i=0; i<a.length;i++){
//            T.add(a[i]);
//
//        }
//        System.out.println(T);
        int[] a = {5, 1, 2, 7, 6, 9, 2};
        for (int i = 0; i < a.length-1 ; i++) {//1,2,5,7,6,9
            for (int j = 0; j < a.length - i - 1; j++) {  //6,
                if (a[j] > a[j + 1]) {
                    //swap
                    int temp = a[j];
                    a[j] = a[j + 1];
                    a[j + 1] = temp;
                }
            }
        }
       System.out.println(Arrays.toString(a));
    }
    }















