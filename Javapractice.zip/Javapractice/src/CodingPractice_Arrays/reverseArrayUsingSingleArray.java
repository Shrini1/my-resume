package CodingPractice_Arrays;



import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;

public class reverseArrayUsingSingleArray{
    public static void main(String[] args) {
        char[] c={'1','2','3','4','5','6','7','8'};  //7,6,5,4,3,2,1   //0 1 2 3 4 5 6 7 8
        int start=0;
        for( int end=c.length-1;start<end;start++){
            char temp=c[start];  //2
            c[start]= c[end];  //
            c[end]= temp;
            end--;
        }
        System.out.println(Arrays.toString(c));









//        char[] c={'1','2','3','4','5','6','7','8'}; //E D C B A
//        int start=0;
//        for (int end = c.length - 1; start<end; end--) {
//            char temp = c[start];  //A B C
//            c[start] = c[end];   //E D C D A
//            c[end] = temp;   // E D C B A
//            start++;
//        }
//
//        System.out.println(c);
//    }
    }
}
