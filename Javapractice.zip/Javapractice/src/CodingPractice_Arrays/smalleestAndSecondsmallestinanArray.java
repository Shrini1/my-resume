package CodingPractice_Arrays;

public class smalleestAndSecondsmallestinanArray {

    public static void main(String[] args) {
        String [] input = {"shrini","Shrinivas","Harshitha","Kirthana","abcd","abc","Bigword"};
        int smallestCount = input[0].toCharArray().length;//2
      //""
        String smallest=input[0];//
        String secondSmallest="";
       // int secondSmallestCount =secondSmallest.toCharArray().length;
        for(int i=0; i<input.length;i++) {
            int currentCount=input[i].toCharArray().length;//3

            if(currentCount<smallestCount) {
                secondSmallest=smallest;
                //secondSmallestCount =secondSmallest.toCharArray().length;
                smallest = input[i];  //a
                smallestCount=currentCount; //
            }
//            secondSmallestCount=currentCount;
//            if(smallestCount<secondSmallestCount && ){
//                secondSmallest=input[i];
//            }
        }
        System.out.println(smallest+" "+secondSmallest);
    }
}
