package CodingPractice_Arrays;

import java.sql.Array;
import java.util.Arrays;
import java.util.TreeSet;

public class sortArrayWithoutArraySort {

    public static void main(String[] args) {
//        String [] input = {"shrini","shrini","shrini","Harshitha","Kirthana","abcd","abc","Bigword"};
//        String newInput="";
////array sort using without  array.sort
//        TreeSet<String> T=new TreeSet<>();
//            for(String s: input){
//                boolean b=T.add(s);
//            }
//        System.out.println(T);

        //bubble sort with string
        String[] arr={"shrini","shrini","shrini","Harshitha","Kirthana","abcd","abc","Bigword"};

        for(int j=0; j<arr.length-1;j++){   //shrini
            for(int k=0;k<arr.length-1-j;k++){  // 7
                if (arr[k].compareTo(arr[k +1])>0) { //shrini  Harshita >0
                String temp=arr[k];
                arr[k]=arr[k +1];
                arr[k + 1]= temp;
                }
            }
        }
        for(String S: arr){
            System.out.println(S+ " ");
        }
    }



}

