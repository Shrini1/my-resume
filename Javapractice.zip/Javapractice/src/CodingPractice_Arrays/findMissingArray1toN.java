package CodingPractice_Arrays;

import java.util.Arrays;

public class findMissingArray1toN {
    public static void main(String[] args) {
//        int[] a={1,2,3,4,5,6,7,9,10,11};
//        int n=a[a.length-1];
//        int expCount=n*(n+1)/2; //66
//        int count=0;
//        for(int i=0;i<a.length;i++){
//          count =count+a[i];//58
//
//        }
//        System.out.println(expCount-count);
        //multiple missing numbers in array 1-n
        int[] b={2,4,5,10,11};
        int m=b[b.length-1]; //11

        boolean[] seen=new boolean[m+1];// boolean seen={1=true,2=true,3=false}
        for(int num:b){
            seen[num]=true;  //seen[2]---true seen(4)---true
        }
        System.out.print(Arrays.toString(seen));

        for(int i=1;i<=m;i++){ //traverse from beginning value(1) to ending value(m)
            if(!seen[i]){  //
                System.out.println(i);
            }
        }
    }



}
