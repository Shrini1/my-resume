package CodingPractice_Arrays;

import java.util.Arrays;
import java.util.LinkedHashMap;

public class commonElementsInTwoArrays {
    public static void main(String[] args) {
        String[] array1 = {"Shrinivas", "Manju", "m", "Suraj", "Kirat", "Kirathana", "Kirathana", "Shrinivas", "Manju", "US", "Manju"};
        String[] array2 = {"Shrinivas", "Manju", "x", "m", "d", "k", "l", "mn", "opq", "rs", "m", "Shrinivas"};

        LinkedHashMap<String, Integer> map = new LinkedHashMap<>();

        for (int i = 0; i < array1.length; i++) {
            map.put(array1[i], 1);  // shrinivas
        }
        //"Shrinivas", "Manju", "m", "Suraj", "Kirat", "Kirathana", "Kirathana", "Shrinivas","Manju", "", "Manju"
        for (int j = 0; j < array2.length; j++) {
            if (map.containsKey(array2[j])) {
                map.put(array2[j], map.get(array2[j]) + 1);  // manju 2 shrinivas 2 m2
            }
        }
        for (String L : map.keySet()) {
            if (map.get(L) > 1) {
                System.out.println(L);
            }
        }

    }
}