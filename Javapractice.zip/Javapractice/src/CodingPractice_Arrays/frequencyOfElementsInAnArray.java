package CodingPractice_Arrays;

import java.util.LinkedHashMap;

public class frequencyOfElementsInAnArray {
    public static void main(String[] args) {
        String[] input = {"Shrinivas", "Manju", "harshit", "Suraj", "Kirat", "Kirathana", "Kirathana", "Manju", "Shrinivas", "Manju"};
        LinkedHashMap<String, Integer> map = new LinkedHashMap<>();
        for (int i = 0; i < input.length; i++) {//s
            if (map.containsKey(input[i])) {
                map.put(input[i], map.get(input[i]) + 1);
            } else {
                map.put(input[i], 1);
            }

        }
        System.out.println(map);

        //First first Non Repeated element

        for(String S: map.keySet()){
            if(map.get(S)==1){ //2<1
                System.out.println("First non repeated word is "+S+" & count is "+map.get(S) );
          break;
            }
        }

    }


}
