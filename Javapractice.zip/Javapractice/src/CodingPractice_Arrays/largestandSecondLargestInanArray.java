package CodingPractice_Arrays;

public class largestandSecondLargestInanArray {

    public static void main(String[] args) {

        String[] Example={"Shri", "Manju", "harshit", "Suraj", "Kirat", "Kirathana", "Mirathana", "marshit", "sd" };
        int LargestElementCount =Example[0].toCharArray().length; //8
        String largest=Example[0];  //harshit
        String secondLargest=""; //harshit
        int secondLargestLength=secondLargest.toCharArray().length; //0
        for(int i=0; i<Example.length;i++){
            int count  =Example[i].toCharArray().length; //7

            if(LargestElementCount<count){  //
                secondLargest=largest;
                secondLargestLength=secondLargest.toCharArray().length;//harshit
                largest=Example[i];  // harshit
                LargestElementCount =count; //7

            }
            if(LargestElementCount==count){
               largest=largest+" " +Example[i];
            }

            if(secondLargestLength==count){
                secondLargest=secondLargest+" "+Example[i];
            }

        }
        System.out.println(largest);
        System.out.println(secondLargest);
        }
    }

