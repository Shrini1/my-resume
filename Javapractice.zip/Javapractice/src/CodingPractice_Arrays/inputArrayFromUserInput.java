package CodingPractice_Arrays;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.Scanner;

public class inputArrayFromUserInput {

    public static void main(String[] args) {

//        //with size and array input by user
//        System.out.print("Enter size");
        Scanner SC = new Scanner(System.in);
//        int size=SC.nextInt();
//      //  int[] a=new int[];
//        int[] a=new int[size];
//        for(int i=0;i<size;i++){
//            a[i]=SC.nextInt();
//        }
//        System.out.println(Arrays.toString(a));

        //without input size by user  and just array input by user

        LinkedList<String> list = new LinkedList<>();
        while (SC.hasNextLine()) {
            list.add(SC.nextLine());
        }
        String[] input = new String[list.size()];
        for (int i = 0; i < list.size(); i++) {
            input[i] = list.get(i);
        }
        for(String M:input){
            System.out.println(M);
        }
        System.out.println(Arrays.toString(input));
    }
}

