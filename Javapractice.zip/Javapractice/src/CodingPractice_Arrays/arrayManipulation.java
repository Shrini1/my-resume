 package CodingPractice_Arrays;

public class arrayManipulation {

    public static void main(String[] args) {
        String input[] ={"Sunday","Monday","Tuesday", "Wednesday","Thursday","Friday", "Saturday"};
        String output[]=new String[input.length];
        for(int i=0; i<input.length;i++){
            output[i]= input[i].substring(0,3);  //0, 1 , 2 index it will take, bcz 3rd index is exclusive
        }

         for(String s: output){
            System.out.println(s);
        }

    }
}
