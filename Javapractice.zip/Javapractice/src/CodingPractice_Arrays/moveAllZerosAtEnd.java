package CodingPractice_Arrays;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;

public class moveAllZerosAtEnd {
    public static void main(String[] args) {
        int[] input = {10, 20, 30,0, 20,10,0,9,10};
        int index=0;//3

        System.out.println(Arrays.toString(input));
        //move non zero elements backward
        for(int i=0;i< input.length;i++){ //i=4
            if(input[i]!=0){ //
                input[index]=input[i]; //10,20,30,20,10
                index=index+1; //6
            }

        }
        System.out.println(index);

        //fill remaining with zeros
        while(index< input.length){
            input[index]=0;
            index=index+1; //
        }
        System.out.println(Arrays.toString(input));
    }
}
