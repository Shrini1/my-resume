package CodingPractice_Arrays;

import java.util.Arrays;
import java.util.TreeSet;

public class removeDuplicatesAndSortAnArray {
    public static void main(String[] args) {
        String[] arr={"shrini","shrini","shrini","Harshitha","Kirthana","abcd","abc","Bigword"};

        TreeSet<String> T=new TreeSet<String>();
       for(int i=0; i< arr.length;i++){ //  T.addAll(Arrays.asList(arr)); use this to addall arrays values
           String s=arr[i];
        T.add(s);
       }
      //  T.addAll(Arrays.asList(arr));

        System.out.println(T);


    }
}

