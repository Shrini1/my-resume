public class Deloite_third {
}
