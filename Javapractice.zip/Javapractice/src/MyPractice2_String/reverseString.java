package MyPractice2_String;

import java.util.Scanner;

public class reverseString {
    public static void main(String[] args) {
        Scanner SC=new Scanner(System.in);
        String Word=SC.nextLine(); //10
        String Rev="";
        for(int i=Word.length()-1; i>=0;i--){
            //Rev+=Word.charAt(i);
            char c=Word.charAt(i);
            Rev=Rev+c;
        }
        System.out.println(Rev);
    }
}
