package MyPractice2_String;

import java.util.Scanner;

public class largestWordInSentence {
    public static void main(String[] args) {
        Scanner SC = new Scanner(System.in);
        while (true) {
            String s=SC.nextLine();
            String[] Sentence = s.split("[^A-Za-z0-9]"); // hi
            String Word = Sentence[0]; //ESC
            String Largest = Word; //hi & am //2
            if(Sentence.length>1) {
                for (int i = 1; i < Sentence.length; i++) {
                    if (Word.length() != Sentence[i].length()) {
                        boolean b = Sentence[i].length() > Word.length(); //2>=2
                        if (b == true) {
                            Largest = Sentence[i]; //shri
                            Word = Sentence[i]; //shri
                        }
                    } else {
                        Largest = Largest + " & " + Sentence[i];//hi & am
                        Word=Sentence[i]; //am
                    }

                }
            }else {
                Largest = Word;
            }
            System.out.println(Largest);
            if(s.equals("ESC")){
                break;
            }
        }
    }
}