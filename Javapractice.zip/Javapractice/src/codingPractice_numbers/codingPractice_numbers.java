package codingPractice_numbers;

import java.util.Scanner;

import static java.lang.Character.getNumericValue;

public class  codingPractice_numbers{
    public static void main(String[] args) {
        Scanner S=new Scanner(System.in);
        int number= S.nextInt();  //153   153%10  3
        int value=0;
        int  sum=0;
        int temp=number;
        char[]a= String.valueOf(number).toCharArray();
        for(int i=0; i< a.length;i++){
           int m=getNumericValue(a[i]);
            value+=m*m*m;
        }
        System.out.println(value);
        if(value==temp){
            System.out.println("as per 1st logic code- its armstrong "+ sum);

        }else{
            System.out.println("as per 1st logic code-its not armstrong "+ temp);
        }
        //>better logic below....//////////////////////
        while(number>0){
            int digit= number%10;   //3, 5,
            sum+=digit*digit*digit;  //9+125+
            number /=10;  // number= number/10  //1
        }

        if(temp==sum){
            System.out.println("its armstrong"+ sum);

        }else{
            System.out.println("its not armstrong"+ temp);
        }
    }
}
