package Collection.CustomSorting;

import java.util.TreeSet;

public class sortStudents {

    public static void main(String[] args) {

        students S1=new students(11,"my god",17.01);
        students S2=new students(12,"ohh",17.04);
        students S3=new students(13,"Shree",143.0);
        students S4=new students(14,"Pavithra",143.2);

           sortOnPercentage sortOnPercentage = new sortOnPercentage();
           sortOnName sortOnName= new sortOnName();
           sortOnRollNumber sortOnRollNumber=new sortOnRollNumber();

        TreeSet<students> t=new TreeSet(sortOnPercentage);
        TreeSet<students> t2=new TreeSet(sortOnName);
        TreeSet<students> t3=new TreeSet(sortOnRollNumber);
        t.add(S1);
        t.add(S2);
        t.add(S3);
        t.add(S4);
//        t2.add(S1);
//        t2.add(S2);
//        t2.add(S3);
//        t2.add(S4);
//        t3.add(S1);
//        t3.add(S2);
//        t3.add(S3);
//        t3.add(S4);

        for(students Percentage :t){
           System.out.println("Sorted based on percentage"+Percentage);
        }
//        for(students Name :t2){
//            System.out.println("sorted based on name"+Name);
//        }
//        for(students RollNumebr :t3){
//            System.out.println("sorted based on Roll number"+RollNumebr);
//        }
    }
}
