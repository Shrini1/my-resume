package Collection.CustomSorting;

import java.util.Comparator;

public class sortOnName implements Comparator<students> {

    public int compare(students x, students y){
        return x.name.compareTo(y.name);
    }
}
