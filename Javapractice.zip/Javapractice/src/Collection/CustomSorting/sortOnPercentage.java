package Collection.CustomSorting;

import java.util.Comparator;

public class sortOnPercentage implements Comparator<students> {

    public int compare(students x, students y){
        return y.percentage.compareTo(x.percentage);
    }
}


