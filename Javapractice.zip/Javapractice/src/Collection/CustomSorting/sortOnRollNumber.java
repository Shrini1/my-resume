package Collection.CustomSorting;



import java.util.Comparator;

public class sortOnRollNumber implements Comparator<students> {

    public int compare(students x, students y){
        return x.rollNumber.compareTo(y.rollNumber);
    }
}
