package Collection.CustomSorting;

public class students {

    Integer rollNumber;
    Double percentage;
    String name;

    students(Integer rollNumber,String name, Double percentage){
        this.rollNumber=rollNumber;
        this.percentage=percentage;
        this.name=name;
    }

    @Override
    public String toString() {
        return "Students :"+rollNumber+ " "+percentage+ " " + name;
    }
}
