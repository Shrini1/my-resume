package Collection;

import java.util.TreeSet;

public class Treeset {


    public static void main(String[] args) {
        Car c1=new Car("BENZ",200,19.2);
        Car c2=new Car("Skoda",100,11.2);
        Car c3=new Car("Tata",300,11.3);
        TreeSet<Car> t=new TreeSet();
        t.add(c1);
        t.add(c2);
        t.add(c3);

        for (Car c: t){
            System.out.println(c);
        }
    }
}
