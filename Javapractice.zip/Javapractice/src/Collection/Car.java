package Collection;

public class Car implements Comparable<Car>{
    int cost;
    String brand;
    Double mileage;

     Car(String brand, int cost, Double mileage) {
        this.cost=cost;
        this.brand=brand;
         this.mileage=mileage;
    }

@Override
    public String toString() {
        return "Car : "+brand+" "+cost+ " "+ mileage;
    }
/*comparing with cost */
//    @Override
//    public int compareTo(Car o) {
//        return o.cost-this.cost;
//    }

//    comparing with brand(string)
  @Override
   public int compareTo(Car o) {
      return this.brand.compareTo(o.brand);
  }

//     comparing with mileage(double)
//    @Override
//    public int compareTo(Car o) {
//     //   return Double.compare(this.mileage,o.mileage);
//        return this.mileage.compareTo(o.mileage);
//    }
}
