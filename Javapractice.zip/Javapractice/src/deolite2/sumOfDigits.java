package deolite2;

public class sumOfDigits {
    public static void main(String[] args){
        int num=1234;
        int sum=0;
        while(num>0){
          int lastdigit=num%10;
          sum=sum+lastdigit;
          num=num/10;
        }
        System.out.print(sum);
    }
}
