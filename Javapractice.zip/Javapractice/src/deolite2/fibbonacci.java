package deolite2;

import java.util.Arrays;

public class fibbonacci {
    public static void main(String[] args){
        int[] input={1,2, 3, 5, 8, 13, 21, 34};
        int first=input[0];
        int second=input[1];
        int[] temp=new int[input.length];
        System.out.print(first+", "+second);
        for(int i=0; i<input.length; i++){
            temp[i]=first+second;
            first=second;
            second=temp[i];
            System.out.print(", "+temp[i]);
        }
        Arrays.equals(temp, input);


    }
}
