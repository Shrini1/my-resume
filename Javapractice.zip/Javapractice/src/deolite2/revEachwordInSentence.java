package deolite2;

public class revEachwordInSentence {

    public static void main(String[] args) {
        String senetnce="hi, i am, shrinivas devihsour";
        String [] words=senetnce.split(" ");

        for(String Word: words){
            String rev="";
            for(int i=Word.length()-1; i>=0;i--){
                rev+=Word.charAt(i);  // ma i, ih

            }
            System.out.print(rev+" ");

        }



    }
}
