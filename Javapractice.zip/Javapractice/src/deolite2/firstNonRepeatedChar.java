package deolite2;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Set;

public class firstNonRepeatedChar {
    public static void main(String[] args) {
        String s = "Manjunmath";
        LinkedHashMap<Character, Integer> map = new LinkedHashMap<>();
        Set<Character> m = map.keySet();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (map.containsKey(c)) {
                map.put(c, map.get(c) + 1);
            } else {
                map.put(c, 1);
            }

        }
        for (Character S : map.keySet()) {
            if (map.get(S) == 1) {
                System.out.println("first non reaoted char " + S);
                break;
            }

        }
    }
}
