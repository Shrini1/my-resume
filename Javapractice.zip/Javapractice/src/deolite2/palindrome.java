package deolite2;

public class palindrome {
    public static void main(String[] args) {
        String s="GADAG";
       boolean isPalindrome=true;
       int n=s.length();  //2
       for(int i=0; i<=n/2 ;i++){
           if(s.charAt(i)!=s.charAt(n-i-1)){  //G
               isPalindrome=false;
               break;
           }
       }
        System.out.println(s+" "+isPalindrome);


    }
}
