package MyPractice_String;

public class armstrong {
    public static void main(String[] args){
        int num=153;
        int sum=0;
        int original=num;
      while(num>0){
         int lastdigit=num%10;
         sum+=lastdigit*lastdigit*lastdigit;
         num=num/10;
      }
      if(original==sum){
          System.out.print("its armstrong");

      }
    }
}
