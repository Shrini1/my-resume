package MyPractice_String;

import java.util.LinkedHashMap;
import java.util.Scanner;
import java.util.Set;

public class frequencycountinString {

    public static void main(String[] args) {
        Scanner SC=new Scanner(System.in);
        String S=SC.nextLine();
        int a=S.length();
        System.out.println(a);
        int count=0;
        LinkedHashMap<Character, Integer > map=new LinkedHashMap();
        Set<Character> s=map.keySet();
        for(int i=0; i<S.length(); i++){
          char ch=S.charAt(i);

          if(map.containsKey(ch)){
              map.put(ch, map.get(ch)+1);
          }
          else{
              map.put(ch, 1);
          }
        }
        for( char Key: s)   //for( char Key: map.keySet())
        {
            System.out.println(Key+" "+map.get(Key));
        }
        //System.out.println(map);   //this is also works
    }
}
