package MyPractice_String;

import java.util.Scanner;

public class reverseString {
    public static void main(String[] args) {
        Scanner SC = new Scanner(System.in);

        while (true) {
            String input = SC.nextLine();
            String Rev = "";
            for (int i = input.length() - 1; i >= 0; i--) {
                Rev += input.charAt(i);

            }
            System.out.println(Rev);
        }
    }
}
