package MyPractice_String;

import java.security.Key;
import java.util.LinkedHashMap;
import java.util.Scanner;
import java.util.Set;

public class firstNonRepeatedCharacter {
    public static void main(String[] args) {
        //shrini s-1  h -1  r-3 n-4   //h1 s1
        Scanner SC = new Scanner(System.in);
        String word = SC.nextLine();  //shrish

        LinkedHashMap<Character, Integer> map = new LinkedHashMap<>();//map=[S=1, ]
        Set<Character> s=map.keySet(); //key={'s','h','r','i','s','h'}
        System.out.println(s); //
        System.out.print(map);
        System.out.println(".............");
        for (int i = 0; i < word.length(); i++) {
            char ch = word.charAt(i); //s
            if (map.containsKey(ch)) {
                map.put(ch, map.get(ch) + 1);  //s2 h 2 r1 i 1
            } else {
                map.put(ch, 1);  // s 1
            }
        }
        for (Character M: s){
            if (map.containsKey(M)) {
                map.put(M, map.get(M) + 1);  //s=2 h 2 r1 i 1
            } else {
                map.put(M, 1);  // s 1
            }

        }
            System.out.print(map);
        for (Character M: s){   //s , h r i s h
            System.out.println(".............");
            if(map.get(M)==1){   //
                System.out.print(M); //R
                break;
            }
        }



    }
}

