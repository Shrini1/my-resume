package MyPractice_String;

import java.util.Scanner;

public class revInteger {

    public static void main(String[] args) {
        Scanner SC=new Scanner(System.in);

      while(true) {
          while (!SC.hasNextInt()) {                     //this while loop handle invalid inputs
              System.out.println("please enter integer,  :");
              SC.next();  //clear the previous value
          }
          int n = SC.nextInt();
          int rev = 0;
          int temp=n;
          while (n > 0) {
              int lastdigit = n % 10;
              rev = rev * 10 + lastdigit;
              n = n / 10;
          }
          System.out.println(temp+" reverse integer is "+rev);
      }
    }
}
