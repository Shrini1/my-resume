package MyPractice_String;

public class checkPrime {

    public static void main(String[] args){
        int num=29;
        boolean isPrime=true;
        int n=num/2;
        for(int div=2; div<n; div++){
            if(num%div==0){
                isPrime=false;
                break;
            }
        }

        System.out.print(isPrime);
    }
}
