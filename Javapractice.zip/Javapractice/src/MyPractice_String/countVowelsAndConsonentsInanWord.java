package MyPractice_String;

import java.util.Scanner;

public class countVowelsAndConsonentsInanWord {
    public static void main(String[] args) {
        Scanner SC=new Scanner(System.in);
        String word= SC.nextLine();
       int vowels=0;
       int consonants=0;
        int i=0;   //we can define variable outside for loop aswell
        for(; i<word.length(); i++){
           char c=word.charAt(i);
           if (c== 'a' ||c=='e'||c=='i'||c=='o'||c=='u'){
               vowels++;
           }else {
               consonants++;
           }

      }
        System.out.print("vowels count is: "+vowels+ " consonants counts is :  "+ consonants);
    }
}
