package MyPractice_String;

import java.util.Locale;
import java.util.Scanner;

public class MonthlyExpenditure {

    public static void main(String[] args) {
        Scanner S = new Scanner(System.in);
        double balance = 0.00;

        while (true) {
            String Type=S.nextLine().toLowerCase();
            double InputPrice = S.nextDouble(); //100

            if (Type=="c") {
                balance = balance + InputPrice;
            }
            else{
                balance = balance + InputPrice;
            }
            System.out.println(balance);
        }

    }
}
