package CodingPractice_String;

import java.util.Scanner;

public class reverseEachWordInSentence {

    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter Sentence: ");
        String sentence=sc.nextLine();  // hi manju
        String[]Words= sentence.split(" "); //[hi, manju]
        for(String word: Words){
           for (int w= word.length()-1; w>=0; w--){
               System.out.print(word.charAt(w));
            }
            System.out.print(" ");
        }

    }
}
