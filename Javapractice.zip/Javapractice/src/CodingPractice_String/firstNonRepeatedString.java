package CodingPractice_String;

import java.util.LinkedHashMap;

public class firstNonRepeatedString {
    public static void main(String[] args) {
        String s="Manjumnj".toLowerCase();
        LinkedHashMap<Character, Integer> map=new LinkedHashMap<>();
        for(int i=0; i<s.length();i++){
            char c= s.charAt(i);
            if(map.containsKey(c)){
                 map.put(c,map.get(c)+1);
            }
            else{
                map.put(c, 1);
            }
        }
        System.out.println(map);

        for (Character S: map.keySet()){
            if(map.get(S)==1){
                System.out.println("first non reaoted char "+ S);
                break;
            }
        }
    }
}
