package CodingPractice_String;

import java.util.Scanner;

public class countLargestWordInSentence {
    public static void main(String[] args) {
        Scanner SC = new Scanner(System.in);
        while (true) {
            String sentence = SC.nextLine();  //ESC
            if (sentence.equals("ESC")){
                break;
            }
            String[] Words = sentence.split(" "); //{hi, i, am, shinivas,hi}  //4
            String largest = Words[0 ];   //shr
            for (int i = 1; i < Words.length; i++) {   //4
                if (Words[i].length() > largest.length()) {   //2>7
                    largest = Words[i];  //shr
                }
            }
            System.out.println(largest);


        }
    }
}
