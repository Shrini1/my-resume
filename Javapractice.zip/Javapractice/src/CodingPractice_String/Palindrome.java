package CodingPractice_String;

import java.util.Scanner;

public class Palindrome {
    public static void main(String[] args) {

        /* THIS IS FOR NUMBER(INT) PALINDROME */

        Scanner SC = new Scanner(System.in);

           //SC.nextLine();
            while (true) {
                while(!SC.hasNextInt()) {
                    System.out.println("please enter integer,  :");
                   SC.next();  //clear the previous value
                }
                int n = SC.nextInt();
                int rev = 0;
                int temp = n; //12321  == 12321  100001  --1


                while (n > 0) {
                    int lastdigit = n % 10;   //1
                    rev = rev * 10 + lastdigit; //    12321
                    n = n / 10;  //1

                }
                if (rev == temp) {
                    System.out.println(rev + " is a Palindrome");
                } else {
                    System.out.println(rev + " is not Palindrome");
                }

            }
        }
    }

//            }
//            SC.nextLine();

            /* THIS IS FOR ALL DATATYPE PALINDROME */
//        Scanner S1 = new Scanner(System.in);
//        String S = S1.nextLine();
//        String Rev = "";
//
//        for(
//                int i = S.length() - 1;
//                i >=0;i--)
//         {
//            Rev += S.charAt(i); //Rev = Rev + c; //Rev+=c
//            //Rev = Rev + c; //Rev+=c
//        }
//        if(S.equals(Rev))
//        {
//            System.out.println(Rev + " is a Palindrome");
//        }
//        else
//        {
//            System.out.println(Rev + " is not Palindrome");
//        }
//        }
//    }
//}

