package CodingPractice_String;

import java.util.Scanner;

public class removeBlankSpaces {
    public static void main(String[] args) {
        Scanner SC=new Scanner(System.in);
        String s=SC.nextLine().replace(" ","");
        System.out.println(s);
    }
}
