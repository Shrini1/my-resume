package CodingPractice_String;

import java.util.*;

public class stringAnagram {

    public static void main(String[] args) {
        Scanner SC = new Scanner(System.in);
        String word1 = SC.nextLine().toLowerCase(Locale.ROOT);
        String word2 = SC.nextLine().toLowerCase(Locale.ROOT);
//        System.out.println(word1+" "+word2);
        TreeSet L1 = new TreeSet();
        TreeSet L2 = new TreeSet();
        if (word1.length() == word2.length()) {
            for (int i = 0; i < word1.length(); i++) {
            boolean d=  L1.add(word1.charAt(i));   //[s, h, r, i] h i r s
            boolean m=   L2.add(word1.charAt(i));// [i, r , s , h]  h i r s
            }
            if(L1.equals(L2)){
                System.out.println(L1+ " "+L2);
                System.out.println(word1+" & "+word2+ " is anagrams");
            }
            else{
                System.out.println(L1+ " "+L2);
                System.out.println(word1+" & "+word2+ " is not anagrams");
            }


        }else{
            System.out.println(word1+"&"+word2+ " is not anagrams");
        }
    }
}
