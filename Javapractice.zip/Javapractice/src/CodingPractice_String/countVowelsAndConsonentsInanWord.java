package CodingPractice_String;

import java.util.Scanner;

public class countVowelsAndConsonentsInanWord {

    public static void main(String[] args) {
        Scanner SC = new Scanner(System.in);
        String word1 = SC.nextLine();
        String word = word1.toLowerCase();
        int vowels=0;
        int consonants=0;
        for (int w = 0; w <= word.length() - 1; w++) {
           char ch = word.charAt(w);
            if (ch== 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
                vowels++;
            }

            else {
                consonants++;

            }

        }
        System.out.println("vowels count is: "+vowels);
        System.out.println("consonants count is: "+consonants);
    }
}
