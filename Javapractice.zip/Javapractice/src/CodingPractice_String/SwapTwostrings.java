package CodingPractice_String;

import java.util.Scanner;

public class SwapTwostrings {
    public static void main(String[] args) {
        System.out.println("swap two strings with third variable");
        Scanner SC = new Scanner(System.in);
        String word1 = SC.nextLine();   //shri
        String word2 = SC.nextLine();   //manju
        String Temp=word1;     //shri
        word1=word2;     //manju
        word2=Temp;  // shri

        System.out.println(word1+" "+word2);

        System.out.println("...........................");
        System.out.println("swap two strings without third variable");

        String word3 = SC.nextLine(); //hello     /5
        String word4 = SC.nextLine(); //world    /5

        //helloworld

        word3=word3+word4;   //helloworld

        word4= word3.substring(0,word3.length()-word4.length()); //2,  //hello
        word3= word3.substring(word4.length());  //world
                System.out.println(word3+" "+word4);

        System.out.println("...........................");
        System.out.println("swap two numbers with third variable");

        int a = SC.nextInt();
        int b = SC.nextInt();
        int Temp1=a;
        a=b;
        b=Temp1;
        System.out.println(a+" "+b);

        System.out.println("...........................");
        System.out.println("swap two numbers without third variable");

        int c = SC.nextInt(); //10
        int d=  SC.nextInt(); //20

        c=c+d;//30
        d=c-d; //20
        c=c-d; //10
        System.out.println(c+" "+d);

    }
}
