package CodingPractice_String;

import java.util.Scanner;


//reverse rsting code
public class ReverseString {

    public static void main(String[] args) {
        Scanner S =new Scanner(System.in);
        System.out.print("Enter string: ");;
        String Str= S.nextLine(); //goodmorning  12
        String R=""; //gni

        for (int i=Str.length()-1; i>=0; i--){
            R= R+Str.charAt(i); //g
        }

        System.out.print("Rev string : "+R);

//        revserse string with prinitning revserse string
//        Scanner S =new Scanner(System.in);
//        System.out.print("Enter string: ");;
//        String Str= S.nextLine();
//        String r="";
//        for (int i=Str.length()-1; i>=0; i--){
//
//            // System.out.print( Str.charAt(i));
//            r = r+ Str.charAt(i);
//        }
//
//        System.out.print("Reversed string : "+ r);
//
//    }
    }
}
