package CodingPractice_String;

import java.util.Scanner;

public class revInteger {

    public static void main(String[] args) {
        Scanner SC=new Scanner(System.in);

        while(true) {
            if (!SC.hasNextInt()){
                System.out.println(" please enter integer");
                SC.next();
            }
            int n = SC.nextInt();   //12345
          int rev = 0;  //54321
          int temp=n;   //
          while (n > 0) {
              int lastdigit = n % 10;  //1234%10  4
              rev = rev * 10 + lastdigit;   //54321
              n = n / 10; //123
          }
          System.out.println(temp+" reverse integer is "+rev);
      }
    }
}
