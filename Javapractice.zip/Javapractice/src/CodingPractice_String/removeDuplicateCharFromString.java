package CodingPractice_String;

import java.util.LinkedHashSet;


public class removeDuplicateCharFromString {

    public static void main(String[] args) {
        LinkedHashSet h = new LinkedHashSet();
        String str ="manjunath";
        for(int i= 0;i<=str.length()-1;i++) {    //M
          boolean d= h.add(str.charAt(i));
          if (d==true) {
                String R = String.valueOf(str.charAt(i)); //m a n j u th
                System.out.print(R);
            }

        }

    }
}

