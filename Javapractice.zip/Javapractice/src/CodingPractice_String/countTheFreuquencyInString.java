package CodingPractice_String;

import java.util.LinkedHashMap;
import java.util.Scanner;

public class countTheFreuquencyInString {

    public static void main(String[] args) {
        Scanner SC = new Scanner(System.in);
        String word = SC.nextLine();  //manjunath  //
        LinkedHashMap<Character, Integer> map=new LinkedHashMap<>();  //emopty
        for(int i=0; i<word.length(); i++){
            char ch=word.charAt(i); //m

            if (map.containsKey(ch)){
                map.put(ch,map.get(ch)+1);  //n2 a2
            }else{
                map.put(ch,1);
            }
        }

        for (Character key: map.keySet()){
System.out.println(key + " " + map.get(key));  //all char count in a word
            if(map.get(key)>1) {
                //System.out.println(key + " " + map.get(key)); //dupliacte char count in an word
            }
        }
        }

}



