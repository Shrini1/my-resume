package CodingPractice_String;

import java.util.Arrays;
import java.util.Scanner;

public class fibbonacciSeries {

    public static void main(String[] args) {
        int[] input={1,2,3,5,8,13,21};
        int first=input[0];
        int second=input[1];
        int expectedValue=0;
        int [] output=new int[input.length];

        for (int i=0;i<input.length;i++){
            System.out.println(first+" ");
            output[i]=first;
            expectedValue=first+second;
            first=second;
            second=expectedValue;
            //output[i]=expectedValue;
        }

        if(Arrays.equals(output, input)){
            System.out.println(Arrays.toString(input) +"&"+ Arrays.toString(output) +" is matching so its a fibbaonacci");
        }else{
            System.out.println(Arrays.toString(input) +"&"+ Arrays.toString(output) +" is not matched so its not a fibbaonacci");

        }
        System.out.println(Arrays.toString(output));
    }
}
