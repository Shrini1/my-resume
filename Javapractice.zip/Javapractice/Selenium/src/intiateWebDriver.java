
public class intiateWbDriver {
    public static void main(String[] args) {
        // Set path to ChromeDriver
        System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");
        // Initialize WebDriver
        WebDriver driver = new ChromeDriver();
        try {
            // Navigate to a website
            driver.get("https://www.selenium.dev/");
            // Print page title
            System.out.println("Page Title: " + driver.getTitle());
        } finally {
            // Close the browser
            driver.quit();
        }
    }
}
