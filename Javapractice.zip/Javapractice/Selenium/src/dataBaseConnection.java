import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class dataBaseConnection {
    public static void main(String[] args) {
        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            // 1️⃣ Load JDBC Driver (Optional in recent versions)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // 2️⃣ Establish connection
            con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/testdb", "root", "password");

            // 3️⃣ Create statement
            stmt = con.createStatement();

            // 4️⃣ Execute query
            rs = stmt.executeQuery("SELECT * FROM users");

            // 5️⃣ Process result
            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("id") +
                        ", Name: " + rs.getString("name") +
                        ", Email: " + rs.getString("email"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (con != null) con.close();
            } catch (Exception e) {
                e.printStackTrace();

//                TakesScreenshot ts=(TakesScreenshot) driver;
//                File Src=ts.getScreenShotAs(outputType.File);
//                FileUtility.copy(Src, new File(c:\homepage.png));
            }
        }
    }
}

